
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/dfs_values.csv")
df["Value"] = df["actual"] / (df["salary"] / 1000)

print(df[["salary", "projected", "actual", "Value"]])

plt.plot(df["salary"], df["Value"], marker='o')
plt.axhline(5.0, color='red', linestyle='--', label="Target 5x Value")
plt.xlabel("Salary")
plt.ylabel("Fantasy Points per $1K")
plt.title("DFS Value Hit Rate by Salary")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
