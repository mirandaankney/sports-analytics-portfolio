
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("data/wnba_dfs_sample.csv")

# Print basic value stats
print(df[["Player", "Salary", "Projected_Points", "Actual_Points", "Value"]])

# Plot: Salary vs. Value
plt.figure(figsize=(8, 5))
plt.scatter(df["Salary"], df["Value"], color="purple")
for i, row in df.iterrows():
    plt.text(row["Salary"] + 50, row["Value"], row["Player"], fontsize=8)

plt.title("WNBA DFS Salary vs. Value (Fantasy Points per $1000 Salary)")
plt.xlabel("Salary")
plt.ylabel("Value (FPTS per $1K Salary)")
plt.grid(True)
plt.tight_layout()
plt.show()
