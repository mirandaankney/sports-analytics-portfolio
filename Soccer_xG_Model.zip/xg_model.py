
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt

df = pd.read_csv("data/xg_shots.csv")
X = df[["distance", "angle"]]
y = df["goal"]

model = LogisticRegression().fit(X, y)
probs = model.predict_proba(X)[:, 1]

print("AUC:", roc_auc_score(y, probs))

plt.scatter(df["distance"], probs, c=y, cmap='coolwarm', edgecolor='k')
plt.xlabel("Distance to Goal")
plt.ylabel("Predicted xG")
plt.title("xG Model Predictions vs. Shot Distance")
plt.grid(True)
plt.show()
