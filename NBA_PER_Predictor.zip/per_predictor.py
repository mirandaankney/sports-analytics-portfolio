
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

df = pd.read_csv("data/nba_per_stats.csv")
X = df[["points", "rebounds", "assists", "pace"]]
y = df["PER"]

model = RandomForestRegressor().fit(X, y)
preds = model.predict(X)

print("MSE:", mean_squared_error(y, preds))
print("Feature Importances:", dict(zip(X.columns, model.feature_importances_)))
